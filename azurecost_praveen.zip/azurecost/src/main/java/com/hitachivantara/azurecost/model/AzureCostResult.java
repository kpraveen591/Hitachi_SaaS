package com.hitachivantara.azurecost.model;

import java.util.Map;

import com.hitachivantara.azurecost.model.AzureCostResponse.AzureCostResponseBuilder;

import lombok.Builder;
import lombok.Data;

@Data
//@Builder
public class AzureCostResult {
	private Double cost;//pretaxcost
	private String resourceGroup;
	private String currency;
}
