package com.hitachivantara.azurecost.service;

import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.azure.core.management.AzureEnvironment;
import com.azure.core.management.profile.AzureProfile;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.resourcemanager.costmanagement.CostManagementManager;
import com.azure.resourcemanager.costmanagement.models.ExportType;
import com.azure.resourcemanager.costmanagement.models.FunctionType;
import com.azure.resourcemanager.costmanagement.models.GranularityType;
import com.azure.resourcemanager.costmanagement.models.QueryAggregation;
import com.azure.resourcemanager.costmanagement.models.QueryColumn;
import com.azure.resourcemanager.costmanagement.models.QueryColumnType;
import com.azure.resourcemanager.costmanagement.models.QueryDataset;
import com.azure.resourcemanager.costmanagement.models.QueryDefinition;
import com.azure.resourcemanager.costmanagement.models.QueryGrouping;
import com.azure.resourcemanager.costmanagement.models.QueryResult;
import com.azure.resourcemanager.costmanagement.models.QueryTimePeriod;
import com.azure.resourcemanager.costmanagement.models.TimeframeType;
import com.hitachivantara.azurecost.model.AzureCostRequest;
import com.hitachivantara.azurecost.model.AzureCostResponse;
import com.hitachivantara.azurecost.model.AzureCostResult;
import com.hitachivantara.azurecost.model.TimePeriod;

import static com.hitachivantara.azurecost.util.Constants.*;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AzureCostService {

	public AzureCostResponse getTotalCost(AzureCostRequest azureCostRequest) {
		
		AzureProfile profile = new AzureProfile(azureCostRequest.getTenantId(),azureCostRequest.getSubscriptionId(), AzureEnvironment.AZURE);
		ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
				.clientId(azureCostRequest.getClientId()).clientSecret(azureCostRequest.getClientSecret())
				.tenantId(azureCostRequest.getTenantId()).build();

		CostManagementManager manager = CostManagementManager.authenticate(clientSecretCredential, profile);

		QueryDataset queryDataset = new QueryDataset().withGranularity(GranularityType.fromString(NONE))
				.withAggregation(mapOf(TOTAL_COST,
						new QueryAggregation().withName(PRE_TAX_COST).withFunction(FunctionType.SUM)))
				.withGrouping(Arrays.asList(
						new QueryGrouping().withType(QueryColumnType.DIMENSION).withName(RESOURCE_GROUP)));

		TimeframeType timeframeType = azureCostRequest.getTimeframe() == null ? TimeframeType.MONTH_TO_DATE : azureCostRequest.getTimeframe();

		TimePeriod timePeriod = azureCostRequest.getCustomTimePeriod();
		QueryTimePeriod customTimePeriod = new QueryTimePeriod();
		customTimePeriod.withFrom(new Date(timePeriod.getFrom()).toInstant().atOffset( ZoneOffset.UTC ));
		customTimePeriod.withTo(new Date(timePeriod.getTo()).toInstant().atOffset( ZoneOffset.UTC ));
		QueryDefinition parameters;
		if (timeframeType == TimeframeType.CUSTOM && null != customTimePeriod) {
			parameters = new QueryDefinition().withType(ExportType.ACTUAL_COST)
					        .withTimeframe(timeframeType).withTimePeriod(customTimePeriod)
					        .withDataset(queryDataset);
		} else {
			parameters = new QueryDefinition().withType(ExportType.ACTUAL_COST)
					         .withTimeframe(timeframeType).withDataset(queryDataset);
		}

		QueryResult result = manager.queries().usage(SUBSCRIPTIONS + SLASH + azureCostRequest.getSubscriptionId(), parameters);

		List<AzureCostResult> costResultsList = new ArrayList<>();
		Double totalCost = 0.0;

		List<QueryColumn> columns = result.columns();
		for (int columnIndex = 0; columnIndex < columns.size(); columnIndex++) {
			QueryColumn column = columns.get(columnIndex);
			log.info(column.name());
		}
		List<List<Object>> rows = result.rows();
		for (List<Object> row : rows) {
			Double cost = (Double) row.get(0);
			String resourceGroup = (String) row.get(1);
			String currency = (String) row.get(2);
			List<String> resourceGrupList = azureCostRequest.getResourceGroupList();
			if (CollectionUtils.isEmpty(resourceGrupList) || 
					(!CollectionUtils.isEmpty(resourceGrupList) && resourceGrupList.contains(resourceGroup))) {
				AzureCostResult azureCostResult = new AzureCostResult();
				azureCostResult.setCost(cost);
				totalCost = totalCost + cost;
				azureCostResult.setResourceGroup(resourceGroup);
				azureCostResult.setCurrency(currency);
				costResultsList.add(azureCostResult);
			}
		}
		return AzureCostResponse.builder().resourceGroupCost(costResultsList).totalCost(totalCost).timeFrame(timeframeType).build();
	}

	@SuppressWarnings("unchecked")
	private static <T> Map<String, T> mapOf(Object... inputs) {
		Map<String, T> map = new HashMap<>();
		for (int index = 0; index < inputs.length; index += 2) {
			String key = (String) inputs[index];
			T value = (T) inputs[index + 1];
			map.put(key, value);
		}
		return map;
	}

}
