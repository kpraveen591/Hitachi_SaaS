package com.hitachivantara.azurecost.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hitachivantara.azurecost.model.AzureCostRequest;
import com.hitachivantara.azurecost.model.AzureCostResponse;
import com.hitachivantara.azurecost.service.AzureCostService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/azure")
@Slf4j
public class AzureCostController {
	
	@Autowired
	private AzureCostService AzureCostService;

	@PostMapping(value = "/totalcost")
	public AzureCostResponse processGet(@RequestBody AzureCostRequest azureCostRequest) {
		AzureCostResponse azureCostResponse = null;
		try {
			log.info("##### /azure/totalcost GET method invoked");
			azureCostResponse = AzureCostService.getTotalCost(azureCostRequest);
		} catch(Exception e) {
			log.error("Error while fetching azure total cost details", e);
		}
		return azureCostResponse;
	}

}
