package com.hitachivantara.azurecost.model;

import java.util.List;

import com.azure.resourcemanager.costmanagement.models.QueryTimePeriod;
import com.azure.resourcemanager.costmanagement.models.TimeframeType;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AzureCostRequest {

	private String tenantId;
    private String subscriptionId;
    private String clientId;
    private String clientSecret;
    private TimeframeType timeframe;
    private TimePeriod customTimePeriod;
    private List<String> resourceGroupList;
}
