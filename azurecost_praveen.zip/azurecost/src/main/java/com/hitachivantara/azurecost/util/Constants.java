package com.hitachivantara.azurecost.util;

public class Constants {

	private Constants() {
	}

	public static final String NONE = "None";
	public static final String TOTAL_COST = "totalCost";
	public static final String PRE_TAX_COST = "PreTaxCost";
	public static final String RESOURCE_GROUP = "ResourceGroup";
	public static final String SUCCESS = "SUCCESS";
	public static final String CURRENCY = "Currency";
	public static final String SUBSCRIPTIONS = "subscriptions";
	public static final String SLASH = "/";
}
