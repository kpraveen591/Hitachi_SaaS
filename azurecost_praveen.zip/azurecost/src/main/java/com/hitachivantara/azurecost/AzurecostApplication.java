package com.hitachivantara.azurecost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzurecostApplication {

	public static void main(String[] args) {
		SpringApplication.run(AzurecostApplication.class, args);
	}

}
